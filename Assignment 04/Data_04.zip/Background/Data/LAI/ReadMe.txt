Leaf area index series were obtained in 500m resolution from
https://www.earthdata.nasa.gov/data/catalog/lpcloud-vnp15a2h-002
and are documented in
https://lpdaac.usgs.gov/documents/126/VNP15_User_Guide.pdf

The extracted time series show LAI values for a pixel with dense and a pixel with sparse vegetation on DTU campus