Meteorological data have been obtained from
https://weatherdata.construct.dtu.dk/data/
The units for the different series can be seen on the same page.
